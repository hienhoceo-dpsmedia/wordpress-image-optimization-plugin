# Changelog

All notable changes to the Image Optimization plugin will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.0] - 2024-08-30

### Added
- Complete rewrite for WordPress.org compliance
- Proper object-oriented structure with separate classes
- Comprehensive internationalization (i18n) support
- Enhanced security with proper sanitization and validation
- Proper activation/deactivation hooks
- Uninstall cleanup functionality
- PHP DocBlocks for all functions and classes
- Export functionality for optimization reports (JSON/CSV)
- Media library integration with status columns
- Bulk conversion actions in Media Library
- Individual convert actions for single images
- Real-time progress tracking with visual indicators
- Enhanced error handling and user feedback
- Comprehensive admin notices system
- **NEW: Revert functionality** - Remove all WebP files with one click
- **NEW: .htaccess rules management** - Automatic generation and management of WebP serving rules
- **NEW: .htaccess status checker** - Real-time status of server rules
- **NEW: Enhanced fallback explanation** - Clear guidance on URL replacement vs .htaccess rules
- **NEW: Plugin benefits explanation** - Better documentation of manual vs automatic optimization
- **NEW: Rules preview** - See exactly what .htaccess rules will be added
- **NEW: Improved .htaccess rules** - Enhanced rules with better file checks, case-insensitive matching, and proper MIME handling

### Changed
- Improved code organization and file structure
- Enhanced admin interface with better UX
- Better settings validation and sanitization
- Improved nonce handling for security
- Enhanced AJAX error handling
- Better progress feedback during conversions
- Improved responsive design for mobile devices
- Updated .htaccess rules for better reliability and safety
- Enhanced branding and company information

### Fixed
- Security vulnerabilities with proper input sanitization
- Nonce verification for all AJAX requests
- Proper capability checks for all admin functions
- Memory optimization for large image processing
- Better error handling for edge cases
- .htaccess rules now include proper file existence checks
- Removed forced Content-Type headers for better compatibility
- Added case-insensitive matching for image extensions

### Security
- Added proper nonce verification for all forms
- Improved capability checks throughout the plugin
- Enhanced input sanitization and validation
- Secure file handling and path validation

## [2.0.0] - 2024-07-15

### Added
- Thumbnail image optimization support
- Fallback URL replacement system for non-LiteSpeed sites
- Enhanced analytics and reporting dashboard
- Bulk conversion tools
- Advanced progress tracking
- Better LiteSpeed Cache integration

### Changed
- Major UI/UX improvements
- Enhanced settings management
- Improved conversion algorithms
- Better error reporting

### Fixed
- Various performance improvements
- Memory usage optimization
- Better handling of large image libraries

## [1.0.0] - 2024-06-01

### Added
- Initial release
- Basic WebP conversion functionality
- Simple dashboard interface
- Original image processing
- Basic LiteSpeed Cache integration
- Manual optimization controls

### Features
- Convert JPEG and PNG images to WebP format
- Configurable quality settings
- Minimum size thresholds
- Basic progress tracking
- Simple admin interface

---

## About This Plugin

**Developed by**: HỒ QUANG HIỂN - DPS.MEDIA JSC  
**Company**: CÔNG TY CỔ PHẦN DPS.MEDIA (DPS.MEDIA Joint Stock Company)  
**Since**: 2017  
**Customers Served**: 5,400+  
**Specialization**: Comprehensive Digital Marketing solutions for SMEs  

**Contact Information**:  
📧 Email: marketing@dps.media  
📞 Phone: +84 961 545 445  
🏢 Address: 56 Nguyễn Đình Chiểu, Tân Định Ward, Ho Chi Minh City, Vietnam  
🌐 Website: https://dps.media/  
🏛️ Tax ID: 0318700500